isLocked = true;
specialChest = true;