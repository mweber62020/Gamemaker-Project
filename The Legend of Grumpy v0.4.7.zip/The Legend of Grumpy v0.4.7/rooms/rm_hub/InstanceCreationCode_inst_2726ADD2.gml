itemHeld = "sword";
isLocked = true;